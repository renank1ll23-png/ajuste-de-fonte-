let size = 16;

document.getElementById("increase").addEventListener("click", () => {
    size += 2;
    document.body.style.fontSize = size + "px";
});

document.getElementById("decrease").addEventListener("click", () => {
    if (size > 8) {
        size -= 2;
        document.body.style.fontSize = size + "px";
    }
});